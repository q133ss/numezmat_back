<div class="comments">
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="comment-block">
            <div class="comment">
                <div class="comment-author">
                    <img src="/assets/img/ava.png" alt="" class="comment-author-avatar">
                    <div class="comment-author-info">
                        <span class="comment-author-nick">
                            <?php echo e('@'.$comment->author->name); ?>

                        </span>
                        <span class="comment-author-date">
                            <?php echo e($comment->date()); ?>

                        </span>
                    </div>
                </div>
                <div class="comment-text">
                    <?php echo $comment->text; ?>

                </div>
                <?php if($comment->coin): ?>
                    <div class="comment-coin">
                        <span class="comment-coin-count">1</span>
                        <?php echo e($comment->coin->title); ?>

                    </div>
                <?php endif; ?>
                <div class="comment-footer">
                    <div class="comment-likes" id="likes-<?php echo e($comment->id); ?>">
                        <div class="comment-like" onclick="commentAction('like', '<?php echo e($comment->id); ?>')">
                            <img src="/assets/img/thumbs-up.png" alt="">
                            <?php echo e($comment->likes()); ?>

                        </div>
                        <div class="comment-dislike" onclick="commentAction('dislike', '<?php echo e($comment->id); ?>')">
                            <img src="/assets/img/thumbs-down.png" alt="">
                            <?php echo e($comment->dislikes()); ?>

                        </div>
                    </div>
                    <div class="comment-footer-right">
                        <button class="comment-answers">
                            Показать ответы
                            <span class="comment-answer-count">
                                    (<?php echo e($comment->replies()->count()); ?>)
                            </span>
                        </button>
                        <button class="comment-answer" data-post="<?php echo e($postId); ?>" data-type="<?php echo e($type); ?>" data-reply="<?php echo e($comment->id); ?>">
                            <img src="/assets/img/corner-down-right.png" alt="">
                            Ответить
                        </button>
                    </div>
                </div>
                <div class="for-answer"></div>
            </div>

            <?php $__currentLoopData = $comment->replies()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="sub-comment display-n">
                    <div class="sub-comment-text">
                        <span class="sub-comment-reply"><?php echo e('@'.$reply->replyAuthor()); ?>, </span>
                        <?php echo e($reply->text); ?>

                    </div>
                    <?php if($reply->coin): ?>
                        <div class="comment-coin" style="margin-top: 10px;">
                            <span class="comment-coin-count">1</span>
                            <?php echo e($reply->coin->title); ?>

                        </div>
                    <?php endif; ?>
                    <div class="sub-comment-footer">
                        <div class="sub-comment-author">
                            by <?php echo e('@'.$comment->author->name); ?>

                        </div>
                        <div class="fix">
                            <button class="comment-answer" data-post="<?php echo e($postId); ?>" data-type="<?php echo e($type); ?>" data-reply="<?php echo e($comment->id); ?>">
                                <img src="/assets/img/corner-down-right.png" alt="">
                                Ответить
                            </button>
                        </div>
                    </div>
                    <div class="for-answer"></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /Applications/MAMP/htdocs/Numezmat/resources/views/includes/comments.blade.php ENDPATH**/ ?>