<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Аккаунт</title>
    <link rel="stylesheet" href="/assets/css/main.css">
    <link rel="stylesheet" href="/assets/css/font-awesome.min.css">
    <!-- Jquery -->
    <script src="https://code.jquery.com/jquery-3.6.3.min.js"
            integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="page-content">

    <section class="page-header">
        <div class="container">
            <div class="page-header-wrap">
                <div class="page-header-left">
                    <ul class="breadcrumbs">
                        <li><a href="/">Главная</a></li>
                        <li>Мой профиль</li>
                    </ul>
                    <div class="page-title-block">
                        <div class="page-img">
                            <img src="/assets/img/profile-ico.png" alt="">
                        </div>
                        <h3 class="page-title">
                            Профиль
                        </h3>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="content-wrap">
        <div class="container">
            <div class="profile-wrap">
                <ul class="profile-menu">
                    <li>
                        <a href="<?php echo e(route('profile.index')); ?>">
                            Настройки профиля
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('profile.money')); ?>">
                            Мои монеты
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('profile.orders')); ?>">
                            Мои заказы
                        </a>
                    </li>
                </ul>
                <div class="profile-content">
                    <div class="profile-img">
                        <img src="<?php echo e($user->avatar()); ?>" class="profile-avatar" alt="">
                        <button type="button" id="change-avatar" class="change-avatar">Заменить фото профиля</button>
                    </div>
                    <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="file" class="display-n" id="profile-img" name="img">
                        <div class="profile-form">

                            <?php if($errors->any()): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="search-header valid-error"><?php echo e($error); ?></span> <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <div class="profile-group">
                                <label>Имя</label>
                                <input type="text" name="name" placeholder="Имя" value="<?php echo e($user->name); ?>">
                            </div>

                            <div class="profile-group">
                                <label>Email</label>
                                <input type="text" name="email" placeholder="Email" value="<?php echo e($user->email); ?>">
                            </div>

                            <div class="profile-group">
                                <label>Старый пароль</label>
                                <input type="password" name="password_old" placeholder="********">
                            </div>

                            <div class="profile-group">
                                <label>Новый пароль</label>
                                <input type="password" name="password_new" placeholder="********">
                            </div>
                        </div>

                        <button class="change-avatar profile-save-btn">Сохранить</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<!-- Mobile menu -->
<?php echo $__env->make('includes.mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ---- -->
<script src="/assets/js/main.js"></script>
<!-- Swiper -->
<script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
<!-- Initialize Swiper -->
<script>
    $('#change-avatar').click(function (){
        $('#profile-img').click();
    });

    $('#profile-img').change(function (){
        let img = $(this).prop('files')[0];
        let form_data = new FormData();
        form_data.append('img', img);

        $.ajax({
            url: "profile/img/update",
            type: "POST",
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: form_data,
            success: function (response) {
                $('.profile-avatar').attr('src', response);
            },
            error: function(data) {
                //console.log(data);
            }
        });
    });
</script>
</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/Numezmat/resources/views/profile/index.blade.php ENDPATH**/ ?>