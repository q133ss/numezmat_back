<?php if(!\App\Models\AdsOrder::getAds($count)->isEmpty()): ?>
    <?php $__currentLoopData = \App\Models\AdsOrder::getAds($count); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e($ad->link); ?>" target="_blank"><img src="<?php echo e($ad->img); ?>" alt="<?php echo e($ad->img); ?>"></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php
        $qty = \App\Models\AdsOrder::getAds($count)->count();
        $diff = $count-$qty;
    ?>

    <?php if($qty < $count): ?>
        <?php for($i = 0; $i<$diff; $i++): ?>
            <img src="/assets/img/ads.jpg" alt="">
        <?php endfor; ?>
    <?php endif; ?>
<?php else: ?>
    <?php for($i = 0; $i < $count; $i++): ?>
        <a href="#request-ads" rel="modal:open"><img src="/assets/img/ads.jpg" alt=""></a>
    <?php endfor; ?>
<?php endif; ?>
<?php /**PATH /Applications/MAMP/htdocs/Numezmat/resources/views/includes/ad.blade.php ENDPATH**/ ?>