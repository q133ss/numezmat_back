<!-- jQuery Modal -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />

<div class="before-header">
    <div class="before-header-container">
        <div class="before-header-left">
            <ul>
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
            </ul>
        </div>
        <div class="before-header-right">
            <ul>
                <li>Телефон: <em>+7(495)123-45-67</em></li>
                <?php if(Auth()->check()): ?>
                    <li><a href="<?php echo e(route('profile.index')); ?>"><?php echo e(Auth()->user()->name); ?></a></li>
                <?php else: ?>
                    <li><a href="<?php echo e(route('login')); ?>">Вход</a></li>
                    <li><a href="<?php echo e(route('register')); ?>">Регистрация</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<header>
    <div class="container">
        <div class="header-wrap">
            <div class="logo">
                <a href="/">
                    <img src="/assets/img/logo.png" alt="">
                </a>
            </div>
            <nav>
                <ul class="header-menu">
                    <li class="menu-item">
                        <a href="<?php echo e(route('news.index')); ?>">Новости</a>
                    </li>

                    <li class="menu-item">
                        <a href="<?php echo e(route('rating.index')); ?>">Определение и оценка</a>
                    </li>

                    <li class="menu-item">
                        <a href="<?php echo e(route('expertise.index')); ?>">Экспертиза</a>
                    </li>

                    <li class="menu-item has-child">
                        <a href="<?php echo e(route('catalog.index')); ?>">Каталог</a>
                        <i class="fa fa-angle-down"></i>

                        <ul class="sub-menu">
                            <?php $__currentLoopData = \App\Models\Category::getMainCategories('App\Models\Catalog')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(\App\Models\Category::where('parent_id', $category->id)->exists()): ?>
                                <li class="sub-has-child" onclick="location.href='<?php echo e(route('catalog.show', $category->id)); ?>'" style="cursor: pointer">
                                    <?php echo e($category->name); ?>

                                    <ul class="sub-sub-menu">
                                        <?php $__currentLoopData = \App\Models\Category::where('parent_id', $category->id)->limit(4)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('catalog.show', $subcat->id)); ?>">
                                                <?php echo e($subcat->name); ?>

                                            </a>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                            <?php else: ?>
                                <li onclick="location.href='<?php echo e(route('catalog.show', $category->id)); ?>'" style="cursor: pointer"><?php echo e($category->name); ?></li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                    </li>

                    <li class="menu-item has-child">
                        <a href="<?php echo e(route('shop.index')); ?>">Магазин</a>
                        <i class="fa fa-angle-down"></i>

                        <ul class="sub-menu">
                            <?php $__currentLoopData = \App\Models\Category::getMainCategories('App\Models\Shop')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(\App\Models\Category::where('parent_id', $category->id)->exists()): ?>
                                    <li class="sub-has-child" onclick="location.href='<?php echo e(route('shop.show', $category->id)); ?>'" style="cursor: pointer">
                                        <?php echo e($category->name); ?>

                                        <ul class="sub-sub-menu">
                                            <?php $__currentLoopData = \App\Models\Category::where('parent_id', $category->id)->limit(4)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a href="<?php echo e(route('shop.show', $subcat->id)); ?>">
                                                        <?php echo e($subcat->name); ?>

                                                    </a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>
                                <?php else: ?>
                                    <li onclick="location.href='<?php echo e(route('shop.show', $category->id)); ?>'" style="cursor: pointer"><?php echo e($category->name); ?></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>

                    <li class="menu-item has-child">
                        <a href="<?php echo e(route('library.index')); ?>">Библиотека</a>
                        <i class="fa fa-angle-down"></i>

                        <ul class="sub-menu">
                            <?php $__currentLoopData = \App\Models\Category::getMainCategories('App\Models\Library')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(\App\Models\Category::where('parent_id', $category->id)->exists()): ?>
                                    <li class="sub-has-child" onclick="location.href='<?php echo e(route('library.show', $category->id)); ?>'" style="cursor: pointer">
                                        <?php echo e($category->name); ?>

                                        <ul class="sub-sub-menu">
                                            <?php $__currentLoopData = \App\Models\Category::where('parent_id', $category->id)->limit(4)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a href="<?php echo e(route('library.show', $subcat->id)); ?>">
                                                        <?php echo e($subcat->name); ?>

                                                    </a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>
                                <?php else: ?>
                                    <li onclick="location.href='<?php echo e(route('library.show', $category->id)); ?>'" style="cursor: pointer"><?php echo e($category->name); ?></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>

                    <li class="menu-item">
                        <a href="<?php echo e(route('forum.index')); ?>">Беседка</a>
                    </li>

                    <li class="menu-item">
                        <button class="header-cart" onclick="location.href='<?php echo e(route('cart.index')); ?>'">
                            <i class="fa fa-shopping-cart"></i>
                            <span id="cart-count">
                                <?php if(session('cart') != null): ?>
                                <?php echo e(count(session('cart'))); ?>

                                <?php else: ?>
                                    0
                                <?php endif; ?>
                            </span>
                        </button>
                    </li>

                    <li>
                        <a href="<?php echo e(route('search')); ?>" class="header-search"><i class="fa fa-search"></i></a>
                    </li>
                </ul>
                <span class="menu-burger" onclick="mobileMenu()">
                        <i class="fa fa-bars"></i>
                    </span>
            </nav>
        </div>
    </div>
</header>
<?php /**PATH /Applications/MAMP/htdocs/Numezmat/resources/views/includes/header.blade.php ENDPATH**/ ?>