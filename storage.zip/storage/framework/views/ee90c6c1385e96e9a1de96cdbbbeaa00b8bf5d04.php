<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($category->name); ?> | Каталог</title>
    <link rel="stylesheet" href="/assets/css/main.css">
    <link rel="stylesheet" href="/assets/css/font-awesome.min.css">
    <!-- Swiper -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css"/>
    <!-- Jquery -->
    <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
</head>
<body>
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">

    <section class="page-header">
        <div class="container">
            <div class="page-header-wrap">
                <div class="page-header-left">
                    <ul class="breadcrumbs">
                        <li><a href="/">Главная</a></li>
                        <li><a href="<?php echo e(route('catalog.index')); ?>">Каталог</a></li>
                        <?php $__currentLoopData = $category->getParents(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('catalog.show', $cat)); ?>"><?php echo e($cat->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($category->name); ?></li>
                    </ul>
                    <div class="page-title-block">
                        <h3 class="page-title">
                            Каталог
                        </h3>
                        <span class="page-sub-title">
                                <?php echo e($category->name); ?>

                        </span>
                    </div>
                </div>
                <div class="page-header-right">

                    
                    
                    
                    

                    <form action="" method="GET">
                        <select name="sort" id="sortSelect" class="page-header-sort">
                            <option value="" >Сортировка</option>
                            <?php $sort = \Request()->query(); ?>
                            <option value="active" <?php if(in_array('active', $sort)): ?> selected <?php endif; ?>>По активности</option>
                            <option value="date" <?php if(in_array('date', $sort)): ?> selected <?php endif; ?>>По дате</option>
                        </select>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <section class="content-wrap">
        <div class="container">
            <div class="posts-page-wrap">
                <div class="posts-wrapper">
                    <div class="actions" style="display: flex; gap: 30px; max-height: 50px">
                        <?php if(auth()->check() && Gate::allows('create-sections-expertise')): ?>
                            <?php $args = ['parent_id' => 1]; ?>
                            <a href="<?php echo e(route('catalog.create.section', ['parent_id' => $category->id])); ?>" class="comment-form-btn" style="display: block; margin-bottom: 20px; margin-top: 0;">Добавить новый подраздел</a>
                        <?php endif; ?>

                        <?php if(auth()->check() && Gate::allows('edit-sections-expertise')): ?>
                            <?php $args = ['parent_id' => 1]; ?>
                            <a href="<?php echo e(route('catalog.edit.section', [$category->id])); ?>" class="comment-form-btn" style="display: block; margin-bottom: 20px; margin-top: 0;">Изменить раздел</a>
                        <?php endif; ?>

                        <?php if(auth()->check() && Gate::allows('delete-sections-expertise')): ?>
                            <?php $args = ['parent_id' => 1]; ?>
                            <a href="<?php echo e(route('catalog.delete.section', [$category->id])); ?>" class="rating-show-block-btn" style="display: block; margin-bottom: 20px; margin-top: 0;">Удалить раздел</a>
                        <?php endif; ?>

                        <?php if(auth()->check() && Gate::allows('create-expertise')): ?>
                            <a href="<?php echo e(route('catalog.create', ['category_id' => $category->id])); ?>" class="comment-form-btn" style="display: block; margin-bottom: 20px; margin-top: 0;">Добавить каталог</a>
                        <?php endif; ?>
                    </div>

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="post">
                            <img src="<?php echo e($category->img()); ?>" class="post-image" alt="">
                            <div class="post-content">
                                <div class="post-description">
                                    <h3 class="post-title">
                                        <?php echo e($category->name); ?>

                                    </h3>
                                    <p class="post-except">
                                        <?php echo e($category->description); ?>

                                    </p>

                                    <a href="<?php echo e(route('catalog.show', $category->id)); ?>" class="post-btn">Подробнее
                                        <img src="/assets/img/arrow-left.png" alt="">
                                    </a>
                                </div>

                                <div class="post-info">
                                    <span class="post-info-item">
                                        Монеты:  <span class="post-info-item-count"><?php echo e($category->getItems('ratings', $category->id)->count()); ?></span>
                                    </span>
                                    <span class="post-info-item">
                                        Просмотры:  <span class="post-info-item-count"><?php echo e($category->views_count ?? '0'); ?></span>
                                    </span>
                                    <span class="post-date">
                                        Создано - <?php echo e($category->date()); ?>

                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="search-result">
                            <div class="post">
                                <img src="<?php echo e($item->img()); ?>" class="post-image" alt="">
                                <div class="post-content">
                                    <div class="post-description">
                                        <h3 class="post-title">
                                            <?php echo e($item->title); ?>

                                        </h3>
                                        <p class="post-except">
                                            <?php echo e(strip_tags(mb_substr($item->description, 0, 100))); ?>

                                            <?php if(strlen($item->description) > 100): ?>
                                                ...
                                            <?php endif; ?>
                                        </p>

                                        <a href="<?php echo e(route('catalog.detail', $item->id)); ?>" class="post-btn">Подробнее
                                            <img src="/assets/img/arrow-left.png" alt="">
                                        </a>
                                    </div>
                                    <div class="post-info search-post-info">
                                        <span class="post-info-item">
                                            <!-- Оценки:  <span class="post-info-item-count">64</span> -->
                                        </span>
                                        <span class="post-info-item">
                                            <!-- Просмотры:  <span class="post-info-item-count">64</span> -->
                                        </span>
                                        <span class="post-date">
                                                <?php if(!$item->characteristics->where('key', 'year')->isEmpty()): ?>
                                                Год - <span class="search-val"><?php echo e($item->characteristics->where('key', 'year')->pluck('value')->first()); ?></span>
                                            <?php endif; ?>
                                            <?php if(!$item->characteristics->where('key', 'condition')->isEmpty()): ?>
                                                Состояние - <span class="search-val"><?php echo e($item->characteristics->where('key', 'condition')->pluck('value')->first()); ?></span>
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($items->isEmpty() && $categories->isEmpty()): ?>
                        <div class="post" style="text-align: center"><span class="post-title" style="align-self: center;width: 100%;">Ничего не найдено</span></div>
                    <?php endif; ?>
                    
                </div>
                <div class="ads">
                    <?php if(!$category->getFilters('App\Models\Catalog')->isEmpty()): ?>
                        <div class="filter">
                            <h3 class="characteristics-title">Фильтр</h3>

                            <form action="" class="form-filter">
                                <?php $__currentLoopData = $category->getFilters('App\Models\Catalog'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="filter-group">
                                        <label for="year" class="characteristics-key">
                                            <?php echo e($filter->name); ?>

                                        </label>
                                        <select name="<?php echo e($filter->db_key); ?>" id="year" class="filter-select">
                                            <option value="#" selected disabled>Выбрать</option>
                                            <?php $__currentLoopData = array_unique($category->getFilterValues('catalogs', 'App\Models\Catalog', $filter->db_key)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value); ?>" <?php if(array_key_exists($filter->db_key, \Request()->query()) && \Request()->query()[$filter->db_key] == $value): ?> selected <?php endif; ?>><?php echo e($value); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" id="sort-field" value="date" name="sort">
                                <button class="filter-btn">Фильтровать</button>
                            </form>
                        </div>
                    <?php endif; ?>
                    <?php echo $__env->make('includes.ad', ['count' => 1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

            <?php echo e($items->links('includes.pagination')); ?>

        </div>
    </section>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make('includes.mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/assets/js/main.js"></script>
<!-- Swiper -->
<script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
<!-- Initialize Swiper -->
<script>

    function sort(val){
        $('#sort-field').val(val)
    }

    var swiper = new Swiper(".mySwiper", {
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
            renderBullet: function (index, className) {
                return '<button class="slider-paginate '+className+'"></button>';
            }
        }
    });

    var swiper = new Swiper(".posts-slider", {
        slidesPerView: 3,
        spaceBetween: 30,
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        breakpoints: {
            900:{
                slidesPerView: 1,
            },
            650:{
                slidesPerView: 1,
            },
            350:{
                slidesPerView: 1,
            }
        }
    });

    var swiper = new Swiper(".news-slider", {
        slidesPerView: 2,
        spaceBetween: 30,
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        breakpoints: {
            1250:{
                slidesPerView: 1,
            },
            350:{
                slidesPerView: 1,
            }
        }
    });
</script>
</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/Numezmat/resources/views/catalog/show.blade.php ENDPATH**/ ?>