<!-- Mobile menu -->
<div class="mob-menu-popup display-n" id="mob-menu-popup">
    <div class="mob-menu-popup-content">
        <div id="close-mob-menu" onclick="closeMenu()">
                <span>
                    X
                </span>
        </div>
        <ul>
            <li>
                <a href="/assets/news.html">Новости</a>
            </li>
            <li>
                <a href="/assets/rating.html">Определение и оценка</a>
            </li>
            <li>
                <a href="/assets/expertise.html">Экспертиза</a>
            </li>
            <li>
                <a href="/assets/catalog.html">Каталог</a>
            </li>
            <li>
                <a href="#">Магазин</a>
            </li>
            <li>
                <a href="#">Библиотека</a>
            </li>
            <li>
                <a href="#">Беседка</a>
            </li>
        </ul>
    </div>
</div>
<!-- ---- -->
<?php /**PATH /Applications/MAMP/htdocs/Numezmat/resources/views/includes/mobile.blade.php ENDPATH**/ ?>