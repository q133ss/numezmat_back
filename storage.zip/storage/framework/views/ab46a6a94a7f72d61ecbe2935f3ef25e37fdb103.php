<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Поиск</title>
    <link rel="stylesheet" href="/assets/css/main.css">
    <link rel="stylesheet" href="/assets/css/font-awesome.min.css">
    <!-- Swiper -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css"/>

</head>
<body>
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="page-content">

    <section class="page-header">
        <div class="container">
            <div class="page-header-wrap">
                <div class="page-header-left">
                    <ul class="breadcrumbs">
                        <li><a href="/">Главная</a></li>
                        <li>Поиск</li>
                    </ul>
                    <div class="page-title-block">
                        <div class="page-img">
                            <img src="/assets/img/Search_alt_fill.png" alt="">
                        </div>
                        <h3 class="page-title">
                            Поиск
                        </h3>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="content-wrap search-content">
        <div class="container">
            <div class="search-wrap">
                <form action="">
                <div class="search-request-wrap">
                    <h3 class="search-header">Запрос:</h3>
                    <input type="text" name="search" value="<?php echo e(\Request()->search); ?>" placeholder="Монета 1" class="search-request">
                    <img src="/assets/img/search-inp.png" class="search-inp-ico" alt="">
                </div>
                <div class="search-filters">
                    <div>
                        <label class="search-header">Искать в</label>
                        <select name="category" class="search-filter" id="">
                            <option value="all" <?php if(\Request()->category == 'all'): ?> selected <?php endif; ?>>Везде</option>
                            <option value="news" <?php if(\Request()->category == 'news'): ?> selected <?php endif; ?>>Новости</option>
                            <option value="rating" <?php if(\Request()->category == 'rating'): ?> selected <?php endif; ?>>Оценка</option>
                            <option value="expertise" <?php if(\Request()->category == 'expertise'): ?> selected <?php endif; ?>>Экспертиза</option>
                            <option value="catalog" <?php if(\Request()->category == 'catalog'): ?> selected <?php endif; ?>>Каталог</option>
                            <option value="product" <?php if(\Request()->category == 'product'): ?> selected <?php endif; ?>>Магазин</option>
                            <option value="library" <?php if(\Request()->category == 'library'): ?> selected <?php endif; ?>>Библиотека</option>
                            <option value="forum" <?php if(\Request()->category == 'forum'): ?> selected <?php endif; ?>>Беседка</option>
                        </select>
                    </div>
                    <button type="submit" class="comment-form-btn">Фильтровать</button>
                </div>
                </form>
            </div>

            <div class="search-result-wrap">
                <?php if(!$items->isEmpty()): ?>
                <?php $__currentLoopData = $items->first(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="search-results">
                    <div class="search-result">
                        <div class="news-slide-wrap">
                            <img src="<?php echo e($item->img()); ?>" style="width: 269px" class="news-slide-img" alt="">
                            <div class="news-slide-left-part">
                                <h3>
                                <?php if(isset($item->title)): ?>
                                    <?php echo e($item->title); ?>

                                <?php else: ?>
                                    <?php echo e($item->name ?? '11'); ?>

                                <?php endif; ?>
                                </h3>
                                <?php if($item->getTable() == 'news'): ?>
                                    <a href="<?php echo e(route('news.show', $item->id)); ?>" class="news-slide-btn">Подробнее
                                        <img src="/assets/img/arrow-left.png" alt="">
                                    </a>
                                <?php elseif($item->getTable() == 'ratings'): ?>
                                    <a href="<?php echo e(route('rating.detail', $item->id)); ?>" class="news-slide-btn">Подробнее
                                        <img src="/assets/img/arrow-left.png" alt="">
                                    </a>
                                <?php elseif($item->getTable() == 'expertises'): ?>
                                    <a href="<?php echo e(route('expertise.detail', $item->id)); ?>" class="news-slide-btn">Подробнее
                                        <img src="/assets/img/arrow-left.png" alt="">
                                    </a>
                                <?php elseif($item->getTable() == 'catalogs'): ?>
                                    <a href="<?php echo e(route('catalog.detail', $item->id)); ?>" class="news-slide-btn">Подробнее
                                        <img src="/assets/img/arrow-left.png" alt="">
                                    </a>
                                <?php elseif($item->getTable() == 'products'): ?>
                                    <a href="<?php echo e(route('shop.detail', $item->id)); ?>" class="news-slide-btn">Подробнее
                                        <img src="/assets/img/arrow-left.png" alt="">
                                    </a>
                                <?php elseif($item->getTable() == 'libraries'): ?>
                                    <a href="<?php echo e(route('library.detail', $item->id)); ?>" class="news-slide-btn">Подробнее
                                        <img src="/assets/img/arrow-left.png" alt="">
                                    </a>
                                <?php elseif($item->getTable() == 'forums'): ?>
                                    <a href="<?php echo e(route('forum.detail', $item->id)); ?>" class="news-slide-btn">Подробнее
                                        <img src="/assets/img/arrow-left.png" alt="">
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>



































            </div>
        </div>
    </section>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php echo $__env->make('includes.mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/assets/js/main.js"></script>
<!-- Swiper -->
<script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
<!-- Initialize Swiper -->
<script>
    var swiper = new Swiper(".mySwiper", {
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
            renderBullet: function (index, className) {
                return '<button class="slider-paginate '+className+'"></button>';
            }
        }
    });

    var swiper = new Swiper(".posts-slider", {
        slidesPerView: 3,
        spaceBetween: 30,
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        breakpoints: {
            900:{
                slidesPerView: 1,
            },
            650:{
                slidesPerView: 1,
            },
            350:{
                slidesPerView: 1,
            }
        }
    });

    var swiper = new Swiper(".news-slider", {
        slidesPerView: 2,
        spaceBetween: 30,
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        breakpoints: {
            1250:{
                slidesPerView: 1,
            },
            350:{
                slidesPerView: 1,
            }
        }
    });
</script>
</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/Numezmat/resources/views/search.blade.php ENDPATH**/ ?>