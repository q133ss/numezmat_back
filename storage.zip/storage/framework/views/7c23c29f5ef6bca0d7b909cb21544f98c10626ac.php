<div class="comment-like" onclick="commentAction('like', '<?php echo e($comment->id); ?>')">
    <img src="/assets/img/thumbs-up.png" alt="">
    <?php echo e($comment->likes()); ?>

</div>
<div class="comment-dislike" onclick="commentAction('dislike', '<?php echo e($comment->id); ?>')">
    <img src="/assets/img/thumbs-down.png" alt="">
    <?php echo e($comment->dislikes()); ?>

</div>
<?php /**PATH /Applications/MAMP/htdocs/Numezmat/resources/views/includes/likes.blade.php ENDPATH**/ ?>