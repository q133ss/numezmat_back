<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корзина</title>
    <link rel="stylesheet" href="/assets/css/main.css">
    <link rel="stylesheet" href="/assets/css/font-awesome.min.css">
    <!-- Swiper -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />
    <script src="https://code.jquery.com/jquery-3.6.3.min.js"
            integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>

<body>
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="page-content">

    <section class="page-header">
        <div class="container">
            <div class="page-header-wrap">
                <div class="page-header-left">
                    <ul class="breadcrumbs">
                        <li><a href="/">Главная</a></li>
                        <li>Корзина</li>
                    </ul>
                    <div class="page-title-block">
                        <div class="page-img">
                            <img src="/assets/img/cart-icone.png" alt="">
                        </div>
                        <h3 class="page-title">
                            Корзина
                        </h3>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="content-wrap">
        <div class="container">
            <?php if(session('cart')): ?>
            <table class="cart-table">
                <tr>
                    <th style="width: 275px;">Изображение</th>
                    <th>Название</th>
                    <th>Цена</th>
                    <th style="width:80px">Колличество</th>
                    <th>Удалить</th>
                </tr>

                <?php $total = 0; ?>
                    <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $total += $details['price'] * $details['qty']
                        ?>
                        <tr id="cart-item_<?php echo e($id); ?>">
                            <td>
                                <img class="cart-img" src="<?php echo e($details['img']); ?>" alt="">
                            </td>
                            <td>
                                <span class="cart-title"><?php echo e($details['name']); ?></span>
                            </td>
                            <td><span class="cart-title"><?php echo e($details['price']); ?> ₽</span></td>
                            <td>
                                <div class="cart-qty-wrap">
                                    <button class="cart-qty-btn" onclick="addToCart('<?php echo e($id); ?>')" data-action="plus">+</button>
                                    <input type="text" disabled class="cart-qty" value="<?php echo e($details['qty']); ?>">
                                    <button class="cart-qty-btn" onclick="removeFromCart('<?php echo e($id); ?>')">-</button>
                                </div>
                            </td>
                            <td>
                                <button type="button" onclick="removeCartItem('<?php echo e($id); ?>')">
                                    <img src="/assets/img/cart-close.png" alt="">
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="search-header valid-error"><?php echo e($error); ?></span> <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            <form action="<?php echo e(route('order.store')); ?>" method="POST" class="cart-form">
                <?php echo csrf_field(); ?>
                <h3 class="characteristics-title">Оформить заказ</h3>
                <div class="cart-form-wrap">
                    <div class="login-group">
                        <label>Имя</label>
                        <input type="text" name="fio" placeholder="Имя" value="<?php echo e(old('fio')); ?>">
                    </div>

                    <div class="login-group">
                        <label>Телефон</label>
                        <input type="text" name="phone" placeholder="Телефон" value="<?php echo e(old('phone')); ?>">
                    </div>

                    <div class="login-group">
                        <label>Email</label>
                        <input type="text" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
                    </div>

                    <div class="login-group">
                        <label>Адрес</label>
                        <input type="text" name="address" placeholder="Адрес" value="<?php echo e(old('address')); ?>">
                    </div>
                </div>

                <div class="cart-total">
                    Итого: <span class="cart-total-sum"><?php echo e($total); ?> ₽</span>
                </div>

                <button class="comment-form-btn cart-payment-btn" type="submit">Оплатить</button>
            </form>
            <?php else: ?>
                <div class="post-title">В корзине пусто.</div><a class="page-header-sort" href="<?php echo e(route('shop.index')); ?>">В магазин</a>
            <?php endif; ?>
        </div>
    </section>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php echo $__env->make('includes.mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/assets/js/main.js"></script>
<script>
    function updateCartCount(){
        $.ajax({
            url: "/get-cart-count",
            type: "POST",
            headers: {
                'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
            },
        }).done(function(data) {
            $('#cart-count').text(data);
        });
    }

    $('.cart-qty-btn').click(function () {
        let input = $(this).parent().find('input');
        let cur = parseInt(input.val())
        if ($(this).data('action') == 'plus') {
            input.val(cur + 1);
        } else {
            if (cur > 1) {
                input.val(cur - 1);
            }
        }
    });

    function addToCart(id){
        $.ajax({
            url:"add-to-cart/"+id,
            type: "POST",
            headers: {
                'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
            }
        }).done(function (data){
            getTotal();
        });
    }

    function removeFromCart(id){
        $.ajax({
            url:"update-cart",
            type: "POST",
            data: {
                "id": id,
            },
            headers: {
                'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
            }
        }).done(function (data){
            getTotal();
        });
    }

    function getTotal(){
        //get-total-cart
        $.ajax({
            url:"get-total-cart",
            type: "POST",
            headers: {
                'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
            }
        }).done(function (data){
            $('.cart-total-sum').html(data+' ₽');
        });
    }

    function removeCartItem(id){
        $.ajax({
            url:"delete-from-cart/"+id,
            type: "POST",
            data: {
                "id": id,
            },
            headers: {
                'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
            }
        }).done(function (data){
            $('#cart-item_'+id).remove()
            updateCartCount();
            getTotal();
        });
    }
</script>
</body>

</html>
<?php /**PATH /Applications/MAMP/htdocs/Numezmat/resources/views/cart.blade.php ENDPATH**/ ?>